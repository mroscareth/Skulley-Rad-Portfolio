Skulley Glyph Variable v2.1
────────────────────────────────────────────────

A rune alphabet painted with a single brush. Every stroke is one drop of ink, thick where it lands and sharp where it leaves, built from a short vocabulary: ensō rings, cups, triangles, diamonds and the three-spike crest of Skulley Rad. Uppercase and lowercase, Maya numerals, punctuation and accents.

CONTENTS
────────
• SkulleyGlyphVariable.ttc              OpenType Collection (3 weights in one file)
• SkulleyGlyphVariable-Light.otf        Light  (weight 300)
• SkulleyGlyphVariable-Medium.otf       Medium (weight 500)
• SkulleyGlyphVariable-Bold.otf         Bold   (weight 700)

WHICH FILE SHOULD I USE?
────────────────────────
• To install and go: the .ttc. One file, three weights, one family.
• For web fonts, Figma or design tokens: the individual .otf files.

HOW TO INSTALL
──────────────
• macOS: double-click the file, then "Install Font" in Font Book.
• Windows: right-click, then "Install" (or "Install for all users").
• Linux: copy to ~/.fonts/ and run fc-cache -fv

GLYPH COVERAGE (152 glyphs)
──────────────
• A–Z: 26 runes.
• a–z: the same runes at x-height.
• 0–9: Maya numerals. A drop is one, a bar is five, the ensō is zero.
• Symbols: .,:;!¡?¿'"()[]{}-_—/\|+=<>«»*&%$#@~^`°…·€
• Typographic quotes and en dash: “”‘’–
• Accents: ÁÉÍÓÚÜÑÇáéíóúüñçÀÈÌÒÙÂÊÎÔÛÄËÏÖàèìòùâêîôûäëïö

WRITING
───────
• Inside a word the runes are linked by a fine thread, as if written without
  lifting the brush. The font adds it by itself (contextual alternates, calt);
  a rune on its own stays clean.
• LL and ll become a rune of their own (ligature, liga).

CREDITS
───────
Designed by Oscar Moctezuma Rodríguez.
skulleyrad.com
